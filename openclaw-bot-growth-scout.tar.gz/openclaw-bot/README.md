# openclaw-bot

This repo is intended to hold standalone OpenClaw extensions (skills, prompts, small utilities) separate from the SEO toolkit.

## Included

- `skills/growth-scout/` — Growth Scout (prompt-driven) concept skill.

> Note: Growth Scout is designed to run via OpenClaw scheduled jobs (Gateway dashboard) that post into Discord.
