---
name: growth-scout
version: 0.1.0
summary: "Twice-weekly growth ideas for recipe sites (SEO + email + monetization) with anti-repetition state."
---

# Growth Scout (Prompt Skill)

This skill is intentionally **prompt-first**: it doesn't require a separate web service.

## How it works

1) A scheduled OpenClaw job runs the prompt in `prompts/growth_scout_digest.md`.
2) The agent posts the digest into a Discord channel.
3) The agent keeps a small JSON state file to avoid repeating ideas.

## Files

- `prompts/growth_scout_digest.md` — the digest prompt template.
- `state/growth_scout_state.json` — rolling memory (ideas sent, themes used, last run).

## Setup

1) Create a Discord channel (e.g. `#content-growth-digest`) and copy its channel id.
2) In your Gateway dashboard, create two schedules:
   - Monday morning
   - Thursday morning

Each schedule should run the same task prompt, with a variable for the channel id.

## Recommended schedule task prompt

Use the contents of `prompts/growth_scout_digest.md` and set:
- `DIGEST_CHANNEL_ID`
- site list / priorities

## State

The agent should read + update `state/growth_scout_state.json` each run.

If you prefer DB storage, you can map the same fields into your existing Mongo collections.
